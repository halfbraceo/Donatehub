<?php
// Include the database connection file
include('server1.php');
include('topnav.php');

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if (!isset($_SESSION["login"])) {
    header("Location: login.php");
    exit();
}

// Define the list of donation types
$donation_types = ['Perishable', 'Non-Perishable', 'Canned/Food Package', 'Ingredients and Condiments', 'Baby Food and Supplies', 'Other'];

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $donation_type = $_POST['donation_type'];
    $expiry_date = !empty($_POST['expiry_date']) ? $_POST['expiry_date'] : null;
    $allergy_info = $_POST['allergy_info'];
    $notes = $_POST['notes'];

    // Validation
    if ($donation_type == 'Other' && empty($expiry_date)) {
        $error = "Expiry date is required for 'Other' donation type.";
    } else {
        // Prepare and execute SQL query using mysqli
        $query = "INSERT INTO donation_requests (user_id, donation_type, expiry_date, allergy_info, notes) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        
        // Check if statement preparation was successful
        if ($stmt === false) {
            $error = "Failed to prepare SQL statement: " . $conn->error;
        } else {
            $stmt->bind_param('issss', $_SESSION['userid'], $donation_type, $expiry_date, $allergy_info, $notes);
            
            if ($stmt->execute()) {
                $success = "Your donation request has been submitted successfully.";
            } else {
                $error = "Failed to execute SQL statement: " . $stmt->error;
            }
            
            $stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request Donation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top:50px;
        }
        h1 {
            text-align: center;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }
        .form-group textarea {
            height: 100px;
        }
        .submit-button {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .submit-button:hover {
            background-color: #0056b3;
        }
        .error, .success {
            color: #d9534f; /* Red for error messages */
            color: #5bc0de; /* Light blue for success messages */
            font-weight: bold;
            text-align: center;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Request Donation</h1>

        <?php if (isset($error)): ?>
            <div class="error"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
        <?php elseif (isset($success)): ?>
            <div class="success"><?php echo htmlspecialchars($success, ENT_QUOTES, 'UTF-8'); ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="form-group">
                <label for="donation_type">Donation Type:</label>
                <select id="donation_type" name="donation_type" required>
                    <?php foreach ($donation_types as $type): ?>
                        <option value="<?php echo htmlspecialchars($type, ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($type, ENT_QUOTES, 'UTF-8'); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="expiry_date">Expiry Date:</label>
                <input type="date" id="expiry_date" name="expiry_date">
            </div>

            <div class="form-group">
                <label for="allergy_info">Allergy Information:</label>
                <textarea id="allergy_info" name="allergy_info" placeholder="Any allergy information"></textarea>
            </div>

            <div class="form-group">
                <label for="notes">Notes (Specifications):</label>
                <textarea id="notes" name="notes" placeholder="Additional specifications or notes"></textarea>
            </div>

            <button type="submit" class="submit-button">Submit Request</button>
        </form>
    </div>
</body>
</html>

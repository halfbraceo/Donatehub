<?php
require_once 'server1.php';

// Check if the user is logged in
session_start();
if (!isset($_SESSION['userid'])) {
    header("Location: login.php");
    exit();
}

// Check if the request is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['donation_id'])) {
        $donationId = $_POST['donation_id'];

        // Prepare and execute the delete query
        $query = $conn->prepare("DELETE FROM donations WHERE id = ? AND user_id = ?");
        if ($query === false) {
            die('Prepare failed: ' . htmlspecialchars($conn->error));
        }
        $userId = $_SESSION['userid']; // Get the logged-in user ID
        $query->bind_param("ii", $donationId, $userId);
        $query->execute();
        $query->close();

        // Redirect back to the listings page
        header("Location: listing.php");
        exit();
    }
}

// If the script is accessed without a POST request, redirect to the listings page
header("Location: listing.php");
exit();
?>

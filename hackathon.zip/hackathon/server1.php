<?php
// server.php

// Database connection details
$host = '127.0.0.1';  // or 'localhost'
$dbname = 'hackathon'; // Replace with your database name
$username = 'root'; // Replace with your database username
$password = ''; // Replace with your database password

// Create a new MySQLi object for database connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// You can add any additional configuration or utility functions below
?>

<?php
// Include the database connection file
include('server.php');
include('topnav.php');

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if (!isset($_SESSION["login"])) {
    header("Location: login.php");
    exit();
}

// Define the list of donation types and vehicle types
$donation_types = ['Perishable', 'Non-Perishable', 'Canned/Food Package', 'Ingrediants and Condiments', 'Baby Food and Supplies', 'Other'];
$vehicle_types = ['Car', 'Bike', 'Truck', 'Van', 'Other'];

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $donation_type = htmlspecialchars($_POST['donation_type'], ENT_QUOTES, 'UTF-8');
    $donation_amount = htmlspecialchars($_POST['donation_amount'], ENT_QUOTES, 'UTF-8');
    $other_donation_amount = isset($_POST['other_amount']) ? htmlspecialchars($_POST['other_amount'], ENT_QUOTES, 'UTF-8') : '';
    $vehicle_type = htmlspecialchars($_POST['vehicle_type'], ENT_QUOTES, 'UTF-8');
    $other_vehicle = isset($_POST['other_vehicle']) ? htmlspecialchars($_POST['other_vehicle'], ENT_QUOTES, 'UTF-8') : '';
    $address = htmlspecialchars($_POST['address'], ENT_QUOTES, 'UTF-8');
    $pickup_details = htmlspecialchars($_POST['pickup_details'], ENT_QUOTES, 'UTF-8');
    $expiry_date = htmlspecialchars($_POST['expiry_date'], ENT_QUOTES, 'UTF-8');
    $donation_description = isset($_POST['donation_description']) ? htmlspecialchars($_POST['donation_description'], ENT_QUOTES, 'UTF-8') : '';
    $courier_service = htmlspecialchars($_POST['courier_service'], ENT_QUOTES, 'UTF-8');
    $allergy_info = isset($_POST['allergy_info']) ? htmlspecialchars($_POST['allergy_info'], ENT_QUOTES, 'UTF-8') : '';
    

    // Handle file upload
    $uploaded_files = [];
    $upload_directory = 'uploads/'; // Directory to save files

    if (!is_dir($upload_directory)) {
        mkdir($upload_directory, 0777, true); // Create directory if it doesn't exist
    }

    if (isset($_FILES['donation_images']) && $_FILES['donation_images']['error'][0] == 0) {
        $allowed_types = ['image/jpeg', 'image/png'];
        $file_count = count($_FILES['donation_images']['name']);

        for ($i = 0; $i < $file_count; $i++) {
            $file_type = $_FILES['donation_images']['type'][$i];
            if (in_array($file_type, $allowed_types)) {
                $file_tmp_name = $_FILES['donation_images']['tmp_name'][$i];
                $file_name = basename($_FILES['donation_images']['name'][$i]);
                $file_path = $upload_directory . $file_name;

                if (move_uploaded_file($file_tmp_name, $file_path)) {
                    $uploaded_files[] = $file_path; // Store file path for database
                } else {
                    $error_message = "Error uploading file: $file_name";
                    break;
                }
            } else {
                $error_message = "Only JPG and PNG files are allowed.";
                break;
            }
        }
    }

    // Validate input
    if ($donation_amount == 'other') {
        if (empty($other_donation_amount) || !is_numeric($other_donation_amount) || $other_donation_amount <= 0) {
            $error_message = "Please enter a valid donation amount.";
        } else {
            $donation_amount = $other_donation_amount;
        }
    } elseif (empty($donation_amount) || !is_numeric($donation_amount) || $donation_amount <= 0) {
        $error_message = "Please enter a valid donation amount.";
    }

    if (!isset($error_message)) {
        // Save to database
        $user_id = $_SESSION['userid']; // Assume user ID is stored in session

        $stmt = $pdo->prepare("INSERT INTO donations (user_id, donation_type, donation_amount, vehicle_type, address, pickup_details, expiry_date, donation_description, uploaded_files, courier_service, allergy_info) VALUES (:user_id, :donation_type, :donation_amount, :vehicle_type, :address, :pickup_details, :expiry_date, :donation_description, :uploaded_files, :courier_service, :allergy_info)");

        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':donation_type', $donation_type);
        $stmt->bindParam(':donation_amount', $donation_amount);
        $stmt->bindParam(':vehicle_type', $vehicle_type);
        $stmt->bindParam(':address', $address);
        $stmt->bindParam(':pickup_details', $pickup_details);
        $stmt->bindParam(':expiry_date', $expiry_date);
        $stmt->bindParam(':donation_description', $donation_description);
        $stmt->bindParam(':courier_service', $courier_service);
        $stmt->bindParam(':allergy_info', $allergy_info);

        // Store file paths in the database
        $file_paths = implode(',', $uploaded_files);
        $stmt->bindParam(':uploaded_files', $file_paths);

        if ($stmt->execute()) {
            $success_message = "Your donation has been successfully recorded. Thank you!";
        } else {
            $error_message = "An error occurred while processing your donation. Please try again.";
        }
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donate</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 70px;
        }
        h1 {
            text-align: center;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group {
            margin-bottom: 20px;
        }
        input[type="text"],
        select,
        input[type="submit"],
        input[type="file"],
        input[type="date"] {
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"] {
            background-color: #333;
            color: #fff;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }
        input[type="submit"]:hover {
            background-color: #555;
        }
        .error {
            color: red;
            margin-bottom: 20px;
        }
        .success {
            color: green;
            margin-bottom: 20px;
        }
        .radio-group {
            margin-bottom: 20px;
        }
        .radio-group label {
            margin-right: 20px;
            font-weight: normal;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Donate</h1>
        <?php if (isset($error_message)): ?>
            <div class="error"><?php echo $error_message; ?></div>
        <?php endif; ?>
        <?php if (isset($success_message)): ?>
            <div class="success"><?php echo $success_message; ?></div>
        <?php endif; ?>
        <form action="donation.php" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="donation_type">Donation Type:</label>
                <select name="donation_type" id="donation_type">
                    <?php foreach ($donation_types as $type): ?>
                        <option value="<?php echo $type; ?>"><?php echo $type; ?></option>
                    <?php endforeach; ?>
                </select>
                <input type="text" id="other_donation_description" name="donation_description" placeholder="Enter description" style="display: none;">
            </div>
            
            <div class="form-group">
                <label>Donation Amount:</label>
                <div class="radio-group">
                    <label><input type="radio" name="donation_amount" value="20" /> 1-2 person</label>
                    <label><input type="radio" name="donation_amount" value="50" /> 3-4 person</label>
                    <label><input type="radio" name="donation_amount" value="100" /> 5-10 person</label>
                    <label><input type="radio" name="donation_amount" value="other" /> Other (specify below)</label>
                </div>
                <input type="text" id="other_amount" name="other_amount" placeholder="Enter the amount of ppl" style="display: none;">
            </div>

            <div class="form-group">
                <label>Vehicle Type:</label>
                <div class="radio-group">
                    <?php foreach ($vehicle_types as $type): ?>
                        <label><input type="radio" name="vehicle_type" value="<?php echo $type; ?>" /> <?php echo $type; ?></label>
                    <?php endforeach; ?>
                </div>
                <input type="text" id="other_vehicle" name="other_vehicle" placeholder="Enter vehicle type" style="display: none;">
            </div>
            
            <div class="form-group">
                <label for="address">Address:</label>
                <input type="text" id="address" name="address" placeholder="Enter your address">
            </div>

            <div class="form-group">
                <label for="pickup_details">Pick-up Details:</label>
                <input type="text" id="pickup_details" name="pickup_details" placeholder="Enter pick-up details">
            </div>

            <div class="form-group">
                <label for="expiry_date">Expiry Date:</label>
                <input type="date" id="expiry_date" name="expiry_date">
            </div>
            <div class="form-group">
    <label for="allergy_info">Allergy Information (Optional):</label>
    <input type="text" id="allergy_info" name="allergy_info" placeholder="Enter any allergy information">
</div>
            
            
            <div class="form-group">
    <label for="donation_images">Upload Images (Optional):</label>
    <input type="file" id="donation_images" name="donation_images[]" multiple accept=".jpg, .jpeg, .png">
</div>
            
            <div class="form-group">
    <label>Do you need a courier service?</label>
    <div class="radio-group">
        <label><input type="radio" name="courier_service" value="Yes" /> Yes</label>
        <label><input type="radio" name="courier_service" value="No" /> No</label>
    </div>
</div>
            

            <input type="submit" value="Donate">
        </form>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const donationTypeSelect = document.getElementById('donation_type');
            const otherDonationDescription = document.getElementById('other_donation_description');
            const donationAmountRadios = document.querySelectorAll('input[name="donation_amount"]');
            const otherAmountInput = document.getElementById('other_amount');
            const vehicleTypeRadios = document.querySelectorAll('input[name="vehicle_type"]');
            const otherVehicleInput = document.getElementById('other_vehicle');

            donationTypeSelect.addEventListener('change', function() {
                if (this.value === 'Other') {
                    otherDonationDescription.style.display = 'inline';
                } else {
                    otherDonationDescription.style.display = 'none';
                }
            });

            donationAmountRadios.forEach(radio => {
                radio.addEventListener('change', function() {
                    if (this.value === 'other') {
                        otherAmountInput.style.display = 'inline';
                    } else {
                        otherAmountInput.style.display = 'none';
                    }
                });
            });

            vehicleTypeRadios.forEach(radio => {
                radio.addEventListener('change', function() {
                    if (this.value === 'Other') {
                        otherVehicleInput.style.display = 'inline';
                    } else {
                        otherVehicleInput.style.display = 'none';
                    }
                });
            });
        });
    </script>
</body>
</html>
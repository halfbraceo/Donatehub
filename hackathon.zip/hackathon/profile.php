<?php
ob_start();
require_once 'server.php';
require_once 'topnav.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in
if (!isset($_SESSION['userid'])) {
    header("Location: login.php");
    exit();
}

$userId = $_SESSION['userid'];

// Fetch user info from the database
$query = $conn->prepare("SELECT username, email, last_login FROM userinfo WHERE userid = ?");

if ($query === false) {
    die('Prepare failed: ' . htmlspecialchars($conn->error));
}

$query->bind_param("i", $userId);
$query->execute();
$query->bind_result($username, $email, $lastLogin);
$query->fetch();
$query->close();

$_SESSION['username'] = $username;
$_SESSION['email'] = $email;

ob_end_flush();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <style>
    body {
    font-family: Arial, sans-serif;
    margin: 0;
    background-color: #f4f4f4;
    color: black; /* Change text color to black */
}

.sidebar {
    width: 200px;
    background-color: #f4f4f4; /* Light background for sidebar */
    height: calc(100vh - 20px);
    position: fixed;
    top: 99px;
    left: 0;
    padding-top: 20px;
    color: black; /* Change sidebar text color to black */
    border-right: 2px solid #ddd; /* Light border for sidebar */
}

.sidebar a {
    padding: 15px;
    text-decoration: none;
    font-size: 18px;
    color: black; /* Change link color to black */
    display: block;
}

.sidebar a:hover {
    background-color: #e2e2e2; /* Light grey hover background for links */
}

.sidebar a.profile-link {
    color: #56C2DD; /* Highlight color for profile link */
}

.content {
    color: black; /* Change text color to black */
    margin-left: 200px;
    padding: 20px;
    width: calc(100% - 200px);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    height: 100vh;
    box-sizing: border-box;
    background-color: white; /* Change content background color to white */
}

.content-inner {
    text-align: center;
}

.profile-info {
    background-color: #f8f9fa; /* Light background for profile info */
    padding: 10px;
    border-radius: 8px;
    margin-bottom: 10px;
    width: 300px;
    text-align: left;
}

.profile-info p {
    margin: 5px 0;
    color: black; /* Ensure text color is black */
}

.profile-edit {
    background-color: #f8f9fa; /* Light background for profile edit */
    padding: 10px;
    border-radius: 8px;
    margin-bottom: 10px;
    margin-left: 70px;
    width: 150px;
    text-align: center;
}

.profile-edit a {
    color: #56C2DD; /* Highlight color for edit profile link */
    text-decoration: none;
}

.profile-edit a:hover {
    text-decoration: underline;
}
    </style>
</head>
<body>
    <div class="sidebar">
        <a href="profile.php" class="profile-link"><u>Profile</u></a>
        
        <a href="listing.php"><u>My listings</u></a>
        
    </div>  
    <div class="content">
        <div class="content-inner">
            <h1>PROFILE</h1>
            <div class="profile-info">
                <p><strong>Name:</strong> <?php echo htmlspecialchars($username); ?></p>
            </div>
            <div class="profile-info">
                <p><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></p>
            </div>
            <div class="profile-info">
                <p><strong>Last Login:</strong> <?php echo htmlspecialchars($lastLogin); ?></p>
            </div>
            
        </div>
    </div>
</body>
</html>

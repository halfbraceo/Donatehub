<?php
// Database connection using MySQLi
require_once 'server1.php'; // Ensure this file contains the MySQLi connection ($conn)

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if (!isset($_SESSION["login"])) {
    header("Location: login.php");
    exit();
}

// Fetch user information
if (isset($_SESSION["login"])) {
    // Prepare and execute query
    $stmt = $conn->prepare('SELECT * FROM userinfo WHERE username = ?');
    $stmt->bind_param('s', $_SESSION['username']);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $username = htmlspecialchars($user['username'], ENT_QUOTES, 'UTF-8');
    $role = htmlspecialchars($user['role'], ENT_QUOTES, 'UTF-8'); // Fetch and sanitize user role
    // Store and sanitize profile picture in session
}

// Debugging: Log session data
error_log("Session Data: " . print_r($_SESSION, true));

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <style>
        /* Basic styling for the navigation */
     .topnav {
            background-color: #333;
            overflow: hidden;
            display: flex;
            align-items: center; /* Center items vertically */
            position: fixed;
            top: 0;
            width: 100%; /* Make the width dynamic */
             height: 90px; /* Set the height of the topnav */
        }
        html, body {
    margin: 0;
    padding: 0;
}
        
      

        .topnav a {
            float: left;
            display: block;
            color: #f2f2f2;
            text-align: center;
            padding: 14px 20px; /* Adjust padding for spacing */
            text-decoration: none;
            font-size: 20px; /* Increase font size */
        }

        .topnav a:hover {
            background-color: #ddd;
            color: black;
        }

        /* Dropdown container */
        .topnav .dropdown {
            float: left;
            overflow: hidden;
            margin-left: 50px; /* Add margin between dropdowns */
        }

        /* Style the dropdown button */
        .topnav .dropdown .dropbtn {
            font-size: 20px;  /* Increase font size */
            border: none;
            outline: none;
            color: #f2f2f2;
            padding: 14px 20px; /* Adjust padding for spacing */
            background-color: inherit;
            font-family: inherit;
            margin: 0;
        }

        /* Dropdown content (hidden by default) */
        .topnav .dropdown-content {
            display: none;
            position: absolute;
            background-color: #333;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
            position: fixed;
        }

        /* Links inside the dropdown */
        .topnav .dropdown-content a {
            float: none;
            color: #f2f2f2;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            text-align: left;
        }

        /* Add a background color to dropdown links on hover */
        .topnav .dropdown-content a:hover {
            background-color: #ddd;
            color: black;
        }

        /* Show the dropdown menu on hover */
        .topnav .dropdown:hover .dropdown-content {
            display: block;
        }

        /* Profile picture styling */
      

        /* Style the active dropdown link */
        .topnav .dropdown-content a.active {
            background-color: #4CAF50;
            color: white;
        }

        .topnav a[href="about.php"] {
            margin-left: 30px; /* Adjust as needed */
        }
         .topnav a[href="faq.php"] {
            margin-left: 30px; /* Adjust as needed */
        }

      
    
       
        .topnav .dropdown .dropbtn {
            font-size: 20px; /* Increase font size */
            border: none;
            outline: none;
            color: #f2f2f2;
            padding: 14px 20px; /* Adjust padding for spacing */
            background-color: inherit;
            font-family: inherit;
            margin: 0;
            display: flex;
            align-items: center; /* Center items vertically */
            gap: 10px; /* Add space between the profile container and the caret icon */
            height: 50px; /* Set a fixed height for the button */
         }
   
    
    </style>
    <title>Quiz Page</title>
</head>
<body>
    <div class="topnav">
        <a href="options.php">
            <img src="images/heart.png" alt="Heart" style="width: 20px; height: 20px; vertical-align: middle;">
            Donate
        </a>
        <div class="dropdown">
            <button class="dropbtn">
                <img src="images/plus.png" alt="Plus" style="width: 20px; height: 20px; vertical-align: middle;">
                Add Items
            </button>
            <div class="dropdown-content">
                <a href="donation.php">Donor</a>
                <a href="beneficiary.php">Beneficiary</a>
                <a href="contentpage3.php">Rider</a>
            </div>
        </div>
        <a href="request.php">Request</a>
        <a href="faq.php">Courier</a>
        <a href="profile.php" class="profile-link">My Profile</a> <!-- Added My Profile link -->
    </div>
    <!-- Your content goes here -->
</body>
</html>

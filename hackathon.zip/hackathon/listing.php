<?php
require_once 'server.php'; // Make sure server.php is included first
require_once 'topnav.php'; // topnav.php should use the connection established in server.php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in
if (!isset($_SESSION['userid'])) {
    header("Location: login.php");
    exit();
}

$userId = $_SESSION['userid'];

// Fetch all donations for the logged-in user
$query = $conn->prepare("SELECT id, donation_type, donation_amount, vehicle_type, address, pickup_details, expiry_date, donation_description, courier_service, allergy_info FROM donations WHERE user_id = ?");

if ($query === false) {
    die('Prepare failed: ' . htmlspecialchars($conn->error));
}

$query->bind_param("i", $userId);
$query->execute();
$result = $query->get_result();

ob_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Listings</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            background-color: #f4f4f4;
            color: #333;
        }

        .sidebar {
            width: 200px;
            background-color: #fff;
            height: calc(100vh - 20px);
            position: fixed;
            top: 99px;
            left: 0;
            padding-top: 20px;
            border-right: 2px solid #ddd;
        }

        .sidebar a {
            padding: 15px;
            text-decoration: none;
            font-size: 18px;
            color: #333;
            display: block;
        }

        .sidebar a:hover {
            background-color: #e2e2e2;
        }

        .content {
            margin-left: 200px;
            padding: 20px;
            width: calc(100% - 200px);
        }

        .listing-container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .listing-container h2 {
            margin-top: 0;
        }

        .listing-container p {
            margin: 5px 0;
        }

        .delete-button {
            background-color: #e74c3c;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
        }

        .delete-button:hover {
            background-color: #c0392b;
        }
    </style>
    <script>
        function confirmDeletion(form) {
            var confirmation = confirm("Are you sure you want to delete this listing?");
            if (confirmation) {
                form.submit();
            }
            return false; // Prevent form submission until confirmed
        }
    </script>
</head>
<body>
    <div class="sidebar">
        <a href="profile.php"><u>Profile</u></a>
        <a href="listing.php"><u>My Listings</u></a>
        <!-- Add other sidebar links here -->
    </div>
    <div class="content">
        <h1>My Listings</h1>

        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="listing-container">
                <h2>Donation Type: <?php echo htmlspecialchars($row['donation_type']); ?></h2>
                <p><strong>Amount:</strong> <?php echo htmlspecialchars($row['donation_amount']); ?></p>
                <p><strong>Vehicle Type:</strong> <?php echo htmlspecialchars($row['vehicle_type']); ?></p>
                <p><strong>Address:</strong> <?php echo htmlspecialchars($row['address']); ?></p>
                <p><strong>Pickup Details:</strong> <?php echo htmlspecialchars($row['pickup_details']); ?></p>
                <p><strong>Expiry Date:</strong> <?php echo htmlspecialchars($row['expiry_date']); ?></p>
                <p><strong>Description:</strong> <?php echo htmlspecialchars($row['donation_description']); ?></p>
                <p><strong>Allergy Information:</strong> <?php echo htmlspecialchars($row['allergy_info']); ?></p>
                <p><strong>Courier Service:</strong> <?php echo htmlspecialchars($row['courier_service']); ?></p>
                <form action="delete_listing.php" method="post" onsubmit="return confirmDeletion(this);" style="margin-top: 10px;">
                    <input type="hidden" name="donation_id" value="<?php echo htmlspecialchars($row['id']); ?>">
                    <button type="submit" class="delete-button">Delete</button>
                </form>
            </div>
        <?php endwhile; ?>

        <?php
        $query->close();
        $conn->close();
        ob_end_flush();
        ?>
    </div>
</body>
</html>



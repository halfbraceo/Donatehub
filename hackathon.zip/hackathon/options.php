<?php
// Include the database connection file
include('server.php');
include('topnav.php');

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if (!isset($_SESSION["login"])) {
    header("Location: login.php");
    exit();
}

// Fetch donation data for all users
$query = "SELECT donation_type, uploaded_files, donation_amount, vehicle_type, address, pickup_details, expiry_date, donation_description, courier_service, allergy_info FROM donations";
$stmt = $pdo->prepare($query);
$stmt->execute();
$donations = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Donations</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding-top: 60px;
        }
        .donation-item {
            display: flex;
            align-items: center;
            padding: 20px;
            margin-bottom: 10px;
            background-color: #e0e0e0;
            border-radius: 4px;
            text-decoration: none;
            color: inherit;
            cursor: pointer;
        }
        .donation-item img {
            margin-left: 20px;
            max-width: 150px;
            height: auto;
        }
        .donation-item:hover {
            background-color: #d0d0d0;
        }
        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgb(0,0,0);
            background-color: rgba(0,0,0,0.4);
            padding-top: 60px;
        }
        .modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
        .modal-content img {
            max-width: 100%;
            height: auto;
        }
        .request-button {
            display: inline-block;
            padding: 10px 20px;
            margin-top: 20px;
            color: #fff;
            background-color: #007bff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
        }
        .request-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>My Donations</h1>
        <?php foreach ($donations as $donation): ?>
            <div class="donation-item" data-details='<?php echo json_encode($donation); ?>'>
                <p><strong>Donation Type:</strong> <?php echo htmlspecialchars($donation['donation_type'], ENT_QUOTES, 'UTF-8'); ?></p>
                <?php if (!empty($donation['uploaded_files'])): ?>
                    <img src="<?php echo htmlspecialchars($donation['uploaded_files'], ENT_QUOTES, 'UTF-8'); ?>" alt="Donation Image">
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- The Modal -->
    <div id="myModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Donation Details</h2>
            <div id="modalBody">
                <!-- Donation details will be populated here -->
            </div>
            <button id="requestButton" class="request-button">Request Item</button>
        </div>
    </div>

    <script>
        // Get the modal
        var modal = document.getElementById("myModal");

        // Get the <span> element that closes the modal
        var span = document.getElementsByClassName("close")[0];

        // Get all donation items
        var donationItems = document.querySelectorAll(".donation-item");

        // When a donation item is clicked, open the modal
        donationItems.forEach(function(item) {
            item.onclick = function() {
                var details = JSON.parse(this.getAttribute('data-details'));
                var modalBody = document.getElementById("modalBody");
                
                modalBody.innerHTML = `
                    <p><strong>Donation Type:</strong> ${details.donation_type}</p>
                    <p><strong>Donation Amount:</strong> ${details.donation_amount}</p>
                    <p><strong>Vehicle Type:</strong> ${details.vehicle_type}</p>
                    <p><strong>Address:</strong> ${details.address}</p>
                    <p><strong>Pickup Details:</strong> ${details.pickup_details}</p>
                    <p><strong>Expiry Date:</strong> ${details.expiry_date}</p>
                    <p><strong>Donation Description:</strong> ${details.donation_description}</p>
                    <p><strong>Courier Service:</strong> ${details.courier_service}</p>
                    <p><strong>Allergy Information:</strong> ${details.allergy_info}</p>
                `;

                modal.style.display = "block";
            };
        });

        // When the user clicks on <span> (x), close the modal
        span.onclick = function() {
            modal.style.display = "none";
        };

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        };

        // Handle the request button click
        document.getElementById("requestButton").onclick = function() {
            // You can handle the request logic here
            alert("Item Successfully Requested");
            modal.style.display = "none"; // Optionally close the modal
        };
    </script>
</body>
</html>

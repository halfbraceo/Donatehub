<?php
// Include the database connection file
include('server1.php');
include('topnav.php');

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if (!isset($_SESSION["login"])) {
    header("Location: login.php");
    exit();
}

// Fetch donation requests from the database
$query = "SELECT donation_type, expiry_date, allergy_info, notes FROM donation_requests";
$result = $conn->query($query);

if ($result === false) {
    die("Error: " . $conn->error);
}

$donation_requests = [];
while ($row = $result->fetch_assoc()) {
    $donation_requests[] = $row;
}

$result->free();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donation Requests</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 1000px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top:50px;
        }
        h1 {
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Donation Requests</h1>

        <table>
            <thead>
                <tr>
                    <th>Donation Type</th>
                    <th>Expiry Date</th>
                    <th>Allergy Information</th>
                    <th>Notes</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($donation_requests)): ?>
                    <tr>
                        <td colspan="4" style="text-align: center;">No donation requests found.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($donation_requests as $request): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($request['donation_type'], ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars($request['expiry_date'] ?? 'N/A', ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars($request['allergy_info'] ?? 'N/A', ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars($request['notes'] ?? 'N/A', ENT_QUOTES, 'UTF-8'); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>


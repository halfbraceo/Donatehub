<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donation App</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .nav-tabs .nav-link.active {
            background-color: #6f42c1;
            color: white;
        }
        .nav-tabs .nav-link {
            border: 1px solid #6f42c1;
            color: #6f42c1;
        }
        .form-section {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .form-section h3 {
            color: #6f42c1;
            margin-bottom: 15px;
        }
        .btn-custom {
            background-color: #6f42c1;
            color: white;
            border: none;
            transition: background-color 0.3s;
        }
        .btn-custom:hover {
            background-color: #5a33a1;
        }
        .btn-outline-primary.active {
            background-color: #6f42c1;
            color: white;
        }
    </style>
</head>
<body>

<div class="container mt-5">
    <ul class="nav nav-tabs">
        <li class="nav-item">
            <a class="nav-link active" data-bs-toggle="tab" href="#donor">Donor</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#beneficiary">Beneficiary</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#rider">Rider</a>
        </li>
    </ul>

    <div class="tab-content mt-4">
        <!-- Donor Tab -->
        <div id="donor" class="tab-pane fade show active">
            <div class="form-section">
                <h3>Donation Type</h3>
                <form method="post" action="submit.php">
                    <div class="mb-3">
                        <button type="button" class="btn btn-outline-primary me-2 mb-2" onclick="selectDonationType('Perishable Food')">Perishable Food</button>
                        <button type="button" class="btn btn-outline-primary me-2 mb-2" onclick="selectDonationType('Sealed Food')">Sealed Food</button>
                        <button type="button" class="btn btn-outline-primary mb-2" onclick="selectDonationType('Others')">Others</button>
                    </div>
                    <div class="mb-3">
                        <label for="donationDescription" class="form-label">Donation Description</label>
                        <textarea class="form-control" id="donationDescription" name="donationDescription" rows="3" placeholder="Enter details about the donation..."></textarea>
                    </div>
                    <input type="hidden" id="donationType" name="donationType" value="">
                    <button type="submit" class="btn btn-custom">Submit</button>
                </form>
            </div>
        </div>

        <!-- Beneficiary Tab -->
        <div id="beneficiary" class="tab-pane fade">
            <div class="form-section">
                <h3>Types of Food Needed</h3>
                <form method="post" action="submit.php">
                    <div class="mb-3">
                        <button type="button" class="btn btn-outline-primary me-2 mb-2" onclick="selectFoodType('Perishable')">Perishable</button>
                        <button type="button" class="btn btn-outline-primary me-2 mb-2" onclick="selectFoodType('Canned Food')">Canned Food</button>
                        <button type="button" class="btn btn-outline-primary me-2 mb-2" onclick="selectFoodType('Ingredients')">Ingredients</button>
                        <button type="button" class="btn btn-outline-primary mb-2" onclick="selectFoodType('Others')">Others</button>
                    </div>

                    <h3>Open to Receiving Food During</h3>
                    <div class="mb-3">
                        <button type="button" class="btn btn-outline-primary me-2 mb-2" onclick="selectTimeRange('Morning')">Morning</button>
                        <button type="button" class="btn btn-outline-primary me-2 mb-2" onclick="selectTimeRange('Afternoon')">Afternoon</button>
                        <button type="button" class="btn btn-outline-primary mb-2" onclick="selectTimeRange('Evening')">Evening</button>
                    </div>

                    <h3>Select Your Location</h3>
                    <div class="mb-3">
                        <button type="button" class="btn btn-outline-primary mb-2">Select Location</button>
                    </div>

                    <h3>Notes</h3>
                    <div class="mb-3">
                        <textarea class="form-control" id="beneficiaryNotes" name="beneficiaryNotes" rows="3" placeholder="Any additional notes..."></textarea>
                    </div>

                    <input type="hidden" id="foodType" name="foodType" value="">
                    <input type="hidden" id="timeRange" name="timeRange" value="">
                    <button type="submit" class="btn btn-custom">Submit</button>
                </form>
            </div>
        </div>

        <!-- Rider Tab -->
        <div id="rider" class="tab-pane fade">
            <div class="form-section">
                <h3>Rider Page Content</h3>
                <p>Here you can place content related to Riders.</p>
            </div>
        </div>
    </div>
</div>

<script>
    function selectDonationType(type) {
        document.getElementById('donationType').value = type;
    }

    function selectFoodType(type) {
        document.getElementById('foodType').value = type;
    }

    function selectTimeRange(range) {
        document.getElementById('timeRange').value = range;
    }
</script>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>
